<?php
//email parameters
$to = "8881112222@txt.att.net";
$subject = "BBI system alert";
$message = " ";
$from = "pi@bbi.fish";
$headers = "From:" . $from;
$updatetime = 0;
$alerts=0;

// check server for alert states:
//poll SQL settings/ranges
include '/app/tank/www/SQLconn.php';// included in the main "tank" code base at https://github.com/bluebladefish/TankController
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val1 FROM current_conf";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($row["varname"] == "tempgoalreef") {
        	$reefgoal = $row["val1"];
        } else if ($row["varname"] == "tempdeltareef"){
        	$reefdelta = $row["val1"];
        } else if ($row["varname"] == "tempgoalplant"){
        	$plantgoal = $row["val1"];
        } else if ($row["varname"] == "tempdeltaplant"){
        	$plantDelta = $row["val1"];
        }
        //echo ($row["varname"] . "=" . $row["val1"]);
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();
// poll SQL current state
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val, stamp FROM p1_recent";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($row["varname"] == "Reef_temp") {
        	$reefcurrent = $row["val"];
        } else if ($row["varname"] == "Plant_temp"){
        	$plantcurrent = $row["val"];
        } else if ($row["varname"] == "Reef_TO_duration"){
        	$reeftop = $row["val"];
        } else if ($row["varname"] == "Plant_TO_duration"){
        	$planttop = $row["val"];
        }
        $thistime = strtotime($row["stamp"]);
        if ($thistime > $updatetime){
        	$updatetime=$thistime;
        }
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();

$reefdelta = $reefdelta + 1;
$plantDelta = $plantDelta +1;
// reef temperature out of range
if ($reefcurrent >= ($reefgoal+$reefdelta)){
	$message = ("REEF tank temp too HIGH at " . $reefcurrent . " degrees   ");
	$alerts = $alerts +1;
} else if ($reefcurrent <= ($reefgoal-$reefdelta)){
	$message = ("REEF tank temp too LOW at " . $reefcurrent . " degrees   ");
	$alerts = $alerts +1;
}
// plant temperature out of range
if ($plantcurrent >= ($plantgoal+$plantDelta)){
	$message = ($message . "PLANT tank temp too HIGH at " . $plantcurrent . " degrees   ");
	$alerts = $alerts +1;
} else if ($plantcurrent <= ($plantgoal-$plantDelta)){
	$message = ($message . "PLANT tank temp too LOW at " . $plantcurrent . " degrees   ");
	$alerts = $alerts +1;
}
//reef top off = 0
if ($reeftop <= 0){
	$message = ($message . "No top off - reef tank   ");
	$alerts = $alerts +1;
}
//plant top off = 0
if ($planttop <= 0){
	$message = ($message . "No top off - plant tank   ");
	$alerts = $alerts +1;
}
// arduino time sync fail
$curtime = date("m-d-Y H:i");
$lastupdate=(date("Y-m-d H:i", $updatetime));
if ($updatetime < $curtime){
	$message = ($message . "Time Sync issue, system time=" . $curtime . " last update at: " . $lastupdate);
	$alerts = $alerts +1;
}
//echo $message;
//$message = ("sytem settings found:   reef goal=" . $reefgoal . "   reef delta=" . $reefdelta . "   reef current=". $reefcurrent . "   Plant Goal=". $plantgoal . "   Plant delta=" . $plantDelta . "   Plant current=" . $plantcurrent . "   Plant top off=" . $planttop . "   reef top off=" . $reeftop );
if ($alerts > 0){
	if ($alerts > 1){ 
		$subject = ("BBI system: " . $alerts . " alerts");
	} 
	mail($to,$subject,$message,$headers);
}
//echo "Mail Sent.";
?>
