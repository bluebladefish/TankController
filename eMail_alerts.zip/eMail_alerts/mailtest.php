<?php
$to = "8881112222@txt.att.net";
$subject = "PHP Test mail";
$message = "This is a test email";
$from = "pi@bbi.fish";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);
echo "Mail Sent.";
?>

