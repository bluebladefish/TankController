<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>Hello World</p>'; ?> 
 <?php
echo '<p> <br> <br>P0 inbound file: <br>';
$fh = fopen('/app/tank/P0_in.txt','r');
while ($line = fgets($fh)) {
	echo($line);
	echo '<br>'; 
}
fclose($fh);
// echo file_get_contents("/app/tank/P0_in.txt");
echo '</p>'; 	
echo '<p> <br> <br>P1 inbound file: <br>';
$fh = fopen('/app/tank/P1_in.txt','r');
while ($line = fgets($fh)) {
        echo($line);
        echo '<br>';
}
fclose($fh);
//echo file_get_contents("/app/tank/P1_in.txt");
echo '</p>';
echo '<p> <br> <br>P2 inbound file: <br>';
$fh = fopen('/app/tank/P2_in.txt','r');
while ($line = fgets($fh)) {
        echo($line);
        echo '<br>';
}
fclose($fh);
// echo file_get_contents("/app/tank/P2_in.txt");
echo '</p>';
echo '<p> <br> <br>P3 inbound file: <br>';
$fh = fopen('/app/tank/P3_in.txt','r');
while ($line = fgets($fh)) {
        echo($line);
        echo '<br>';
}
fclose($fh);
// echo file_get_contents("/app/tank/P3_in.txt");
echo '</p>';
echo '<p> <br> <br>P4 inbound file: <br>';
$fh = fopen('/app/tank/P4_in.txt','r');
while ($line = fgets($fh)) {
        echo($line);
        echo '<br>';
}
fclose($fh);
// echo file_get_contents("/app/tank/P4_in.txt");
echo '</p>';
echo '<p> <br> <br>all inbound file: <br>';
echo file_get_contents("/app/tank/all_inbound.txt");
echo '</p>';
?>
 </body>
</html>
