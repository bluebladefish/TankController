<?php

include('../phpgraphlib.php');
include('../../SQLconn.php');


$set1 = array();
$set2 = array();
$small = "2018-02-04 10:00:00";
$large = "2018-02-08 13:00:00";

//SQL
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//get data set1 from database
$sql = "SELECT * FROM env_log WHERE varname='Reef_temp' AND stamp BETWEEN '".$small."' AND '".$large."' ORDER BY stamp" ;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $itemValue=$row["val"];
      $itemstamp=$row["stamp"];
      //add to data array
      $set1[$itemstamp]=$itemValue;
  }
}
$conn->close();

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//get data set2 from database
$sql = "SELECT * FROM cont_log WHERE varname='reef_heater' AND stamp BETWEEN '".$small."' AND '".$large."' ORDER BY stamp";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $itemValue=$row["val"];
      $itemstamp=$row["stamp"];
      //add to data array
      if ($itemValue == "ON"){
	$itemValue_convert=82;
      } else {
	$itemValue_convert=68;
      }
      $set2[$itemstamp]=$itemValue_convert;
  }
}
$conn->close();

//configure graph
$graph = new PHPGraphLib(460, 400);
$graph->addData($set1, $set2);
$graph->setTitleLocation('left');
$graph->setTitle("Reef Temperature and Heater activity");
$graph->setBars(false);
$graph->setLine(true);
$graph->setDataPoints(false);
$graph->setLineColor('blue', 'red');
$graph->setDataValues(false);
$graph->setXValuesInterval(2);
$graph->setDataValueColor('blue', 'red');
$graph->setLegend(true);
$graph->setLegendTitle("Reef Temp", "Heater");
$graph->setRange(82,68);
$graph->setupXAxis(26);
$graph->createGraph();


?>