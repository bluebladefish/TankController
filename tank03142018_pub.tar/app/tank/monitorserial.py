#!/usr/bin/env python
import serial
import time
#from mysql.connector import MySQLConnection, Error
from mysql.connector.connection import MySQLConnection
from mysql.connector import errors
from python_mysql_dbconfig import read_db_config
# serial connection, baudrate and timeout may need tuneing
port = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=2.0)
# local files to read or write
sendfile = "/app/tank/serial_out.txt"
recvallfile = "/app/tank/all_inbound.txt"
P0file = "/app/tank/P0_in.txt"
P1file = "/app/tank/P1_in.txt"
P2file = "/app/tank/P2_in.txt"
P3file = "/app/tank/P3_in.txt"
P4file = "/app/tank/P4_in.txt"
setupfile = "/app/tank/savedconfig.txt"
ackstate = 1 
# sql connection to update p1 table
def update_p1_table(myvar_name, myval):
	# read database configuration
	db_config = read_db_config()
	# prepare query and data
	query = """ UPDATE p1_recent
                SET
                        val = %s,
                        stamp = NULL
                WHERE varname = %s """

	data = (myval, myvar_name)
	try:
		conn = MySQLConnection(**db_config)
		# update 
		cursor = conn.cursor()
		cursor.execute(query, data)
		# accept the changes
		conn.commit()
	except Error as error:
		fh = open(P4file, "a")
		fh.write(error + "\n")
		fh.close()
		# print(error)
	finally:
		cursor.close()
		conn.close()
# sql connection to update current configuration table
def update_currconf_table(myvar_name, myval1, myval2, myval3, myval4):
	# read database configuration
	db_config = read_db_config()
	# prepare query and data
	query = """ UPDATE current_conf
                SET
                        val1 = %s,
                        val2 = %s,
                        val3 = %s,
                        val4 = %s,
                        stamp = NULL
                WHERE varname = %s """

	data = (myval1, myval2, myval3, myval4, myvar_name)
	try:
		conn = MySQLConnection(**db_config)
		# update
		cursor = conn.cursor()
		cursor.execute(query, data)
		# accept the changes
		conn.commit()
	except Error as error:
		fh = open(P4file, "a")
		fh.write(error + "\n")
		fh.close()
		# print(error)
	finally:
		cursor.close()
		conn.close()
# sql connection to read saved configuration table and send to arduino
def send_setup_to_ard():
	try:
		dbconfig = read_db_config()
		conn = MySQLConnection(**dbconfig)
		cursor = conn.cursor()
		cursor.execute("SELECT * FROM saved_conf")
		row = cursor.fetchone()
# ..........debug
		# print("sending setup info to PI")
# ..........
		port.write("A0 wait\n")
		time.sleep (20.0 / 1000.0);
		while row is not None:
			port.write("A1 " + ' '.join(str(x) for x in row) + "\n")
			time.sleep (80.0 / 1000.0);
# .......... debug
			# print("A1 " + ' '.join(str(x) for x in row))
# ..........
			row = cursor.fetchone()
	except Error as e:
		fh = open(P4file, "a")
		fh.write(e + "\n")
		fh.close()
		# print(e)
	finally:
# .......... debug
		# print("setup info sent to PI")
# ..........
		port.write("A0 ready\n")
		cursor.close()
		conn.close()

while True:
# read outfile and send to arduino
	fhout = open(sendfile, "r")
	outstring = fhout.read()
	if (outstring != ""):
		port.write(outstring + "\n") 
		fhout.close()
		open(sendfile, 'w').close()
# read inbound from serial buffer
	rcv = port.readline()
	mystring = rcv.split('\r')
# ....... write all inbound to log file for debuging
	# fh = open(recvallfile, "a")
	# fh.write(mystring[0] + "\n")
	# fh.close()
# ......... end write all inbound to log file
# ................ debug
	# print(mystring[0]) # output to console - comment out after debugging
# ................
	substring = mystring[0].split(' ')# parse data into array, split on spaces
# process P0 commands
	if (substring[0] == "P0"):
		# P0 wait\ready\ack\done - only store the last status
		fh = open(P0file, "w")
		fh.write(mystring[0].replace(substring[0], "") + "\n")
		fh.close()
		if (substring[1] == "wait"):
			ackstate = 0
		elif (substring[1] == "done"):
			ackstate = 1
# process P1 commands
	elif (substring[0] == "P1"):
		# P1 {name} {value} {time} 	= send Pi 1 line of logging\status data
		update_p1_table(substring[1],substring[2])
# .......... P1 file disabled - too large - use for debugging
		#fh = open(P1file, "a")
		#fh.write(mystring[0].replace(substring[0], "") + "\n")
		#fh.close()
# ..........
# process P2 commands
	elif (substring[0] == "P2"):
		# P2 setup\setings	= request\report setup\init settings from PI SD
		# if requesting setup info from Pi, send setup info
		if (substring[1] == "setup"):
# .......... debug
			#print("setup info requested from PI") # print to console for debugging
# ..........
			# send setup info
			send_setup_to_ard()
			port.write("A2 setup\n")
		# else it is reporting current config to Pi record to sql
		elif (ackstate == 0): # data sent betweeen "wait" and "done" states
			NVpair = substring[1].split('=')
			# timestamp not reported to database, only in file
			if (NVpair[0] == "CurrentTimestamp"):
				fh = open(P2file, "w")
				fh.write(NVpair[0] + "," + NVpair[1] + "\n")
				fh.close()
			# evrything else to database and file
			else:
				morevalues = NVpair[1].split(',')
				morevalues.extend([0,0,0])		
				update_currconf_table(NVpair[0],morevalues[0], morevalues[1], morevalues[2], morevalues[3])
				fh = open(P2file, "a")
				fh.write(NVpair[0] + "," + NVpair[1] + "\n")
				fh.close()
# process P3 commands 
	elif (substring[0] == "P3"):
	# P3 {time}	= tell Pi current time from RTC
		fh = open(P3file, "w")
		fh.write(mystring[0].replace(substring[0], "") + "\n")
		fh.close()
# process P4 commands
	elif (substring[0] == "P4"):
	# P4 {code} {string}	= inform Pi of error\issue (for logging or alerts)
	# print("P4 found")
		fh = open(P4file, "a")
		fh.write(mystring[0].replace(substring[0], "") + "\n")
		fh.close()
#------- when serial connection teminates, write to error file
fh = open(P4file, "a")
fh.write("serial closed\n")
fh.close()
#print("serial closed")
