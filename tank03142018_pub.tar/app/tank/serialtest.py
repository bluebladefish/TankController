import serial
port = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=20.0)
while True:
	port.write("\r\nA2 setup")
	rcv = port.readline()
	mystring = rcv.split('\r')
	print(mystring[0] + "\n")
