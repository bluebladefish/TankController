#!/bin/bash
CAP_RAW=`/usr/sbin/i2cget -f -y 1 0x36 4 w 2>/dev/null`
VLT_RAW=`/usr/sbin/i2cget -f -y 1 0x36 2 w 2>/dev/null`
CAP_BS=${CAP_RAW:4:2}${CAP_RAW:2:2}
VLT_BS=${VLT_RAW:4:2}${VLT_RAW:2:2}
CAP_DEC=`/bin/echo $((16#${CAP_BS}))`
VLT_DEC=`/bin/echo $((16#${VLT_BS}))`
CAP_VAL=`expr ${CAP_DEC} / 256`
VLT_VAL=`/bin/echo "(${VLT_DEC}*78.125 )/100000" |bc`
VLT_FLT=`/bin/echo "scale=2;(${VLT_DEC}*78.125 )/1000000" |bc`
ALRTSTAT=0
#write batery status to /app/tank/bat_stat.txt
/bin/echo "votage $VLT_FLT, Battery Capacity $CAP_VAL%" > /app/tank/bat_stat.txt
# set threshold for capacity LOW alert
if [ $CAP_VAL -lt 50 ]
        then
        ALRTSTAT=$((ALRTSTAT+1))
        STRING1="Capacity of $CAP_VAL is less than 50%,"
else
        STRING1=" "
fi
# set threshold for voltacge LOW alert
if [ $VLT_VAL -lt 36 ]
        then
        STRING2="Voltage of $VLT_FLT is less than 3.6"
        ALRTSTAT=$((ALRTSTAT+1))
else
        STRING2=" "
fi
if [ $ALRTSTAT -gt 0 ]
        then
        # set threshold for voltacge LOW  - SYSTEM SHUTDOWN
        if [ $VLT_VAL -lt 32 ]
                then
                STRING3="  SHUTTING DOWN  "
                /bin/echo "Pi Shutting Down low voltage at $VLT_FLT" >> /app/tank/P4_in.txt
                php /app/tank/BatteryAlert.php $STRING3 $STRING1 $STRING2
                sleep 10
                sudo shutdown -h now
        fi
        php /app/tank/BatteryAlert.php $STRING1 $STRING2
fi

