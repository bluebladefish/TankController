<?php
$to = "#####@your.phone.domain.net";
$subject = "PIfish Battery LOW alert";
$message = "Battery status: ";
$from = "pi@bbi.fish";
$headers = "From:" . $from;

if (isset($argc)) {
        for ($i = 1; $i < $argc; $i++) {
                #echo "Argument #" . $i . " " . $argv[$i] . "\n";
                $message = $message . " " . $argv[$i];
        }
        echo $message;
}
else {
        echo "argc and argv disabled\n";
}

mail($to,$subject,$message,$headers);
#echo "Mail Sent.";
?>


