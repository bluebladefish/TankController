please refrence https://www.youtube.com/watch?v=0RoCMCgFoCY for sending text alerts first,
this build depends on text alerts being configured, though if you do not want them you may comment out the lines that call BatteryAlery.php

1.  Upgrade software:
sudo apt-get update
sudo apt-get upgrade

2.  Enable the I2C function via raspi-config tool.

3.  Install wiringPi .  git clone git://git.drogon.net/wiringPi
git clone https://github.com/WiringPi/WiringPi.git
cd WiringPi
./build

4. configure i2c ups battery level tools
sudo apt-get install i2c-tools
sudo i2cdetect -y -a 1

# test - check capacity:
sudo i2cget -f -y 1 0x36 4 w
#swap between the high byte and low byte, convert to dec and divide by 256

# test - check voltage
sudo i2cget -f -y 1 0x36 2 w
#swap between the high byte and low byte, convert to decimal and for this multiply by 78.125 then divide by a million (move the decimal point)
 
5. install BC for binary to decimal conversion
sudo apt install bc

6. copy battery.sh and BatteryAlert.php to /app/tank and then set permissions
cd /app/tank
chmod 755 BatteryAlert.php
chmod 755 battery.sh 

7. create bat_stat.txt file and set permissions
touch /app/tank/bat_stat.txt
chmod 777 /app/tank/bat_stat.txt

8. add cron task to call battery.sh every 5 min:
crontab -e
#(add the following lines to the end:)
5,10,15,20,25,30,35,40,45,50,55 * * * * /app/tank/battery.sh
