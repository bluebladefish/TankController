<?php
//echo date("Y-m-d H:i:s");
echo "start\r\n";
echo date("Y");
echo "\r\n";
echo date("m");
echo "\r\n";
echo date("d");
echo "\r\n";
echo date("H");
echo "\r\n";
echo date("i");
echo "\r\n";
echo date("s");
echo "\r\n";
echo "end\r\n";
?>
