<?php
     	if ($_SERVER['REQUEST_METHOD'] == "POST"){
    		$val1 = $_REQUEST['val1'];
    		$varname = $_REQUEST['varname'];
    		if ($varname == 'time'){
    			writetofile($val1);
    		} else if ($varname == 'clear'){
    			writetofile2("");
    		} else {
    			writetoDB($varname, $val1);
    			//phpAlert($txt);
    		}
    	} else {
    		echo ("command recieved but not understood");
    	}
   
function phpAlert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}

function writetofile($outtxt) {
    $fh = fopen('/app/tank/www/devices/ESPcont1/time.txt','w'); // <-- update path here
    fwrite($fh, $outtxt);
    fclose($fh);
    echo "File Written";
    //sleep(3);
}

function writetofile2($outtxt) {
    $fh = fopen('/app/tank/www/devices/ESPcont1/data.txt','w'); // <-- update path here
    fwrite($fh, $outtxt);
    fclose($fh);
    echo "File cleared";
    //sleep(3);
}

function writetoDB($variable, $v1) {
	include '../../SQLconn.php';
	// Create connection
	$conn = new mysqli($servername, $username, $password, $devicedbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = ("UPDATE recent SET val='" . $v1 . "', stamp=now() WHERE varname='" . $variable . "'");
	if ($conn->query($sql) === TRUE) {
		//phpAlert("Record updated successfully");
		echo ("DB updated: ");
		echo (" UPDATE recent SET val='" . $v1 . "' WHERE varname='" . $variable . "'");
	} else {
		//phpAlert("Error updating record: " . mysqli_error($conn));
		echo ("Error updating record: " . mysqli_error($conn));
	}
	mysqli_close($conn);
	$conn->close();
}


?>