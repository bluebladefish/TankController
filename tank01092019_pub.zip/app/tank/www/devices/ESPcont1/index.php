<!DOCTYPE html>

<html lang="en">

<head>

  
<!-- Basic Page Needs
  �������������������������������������������������� -->

  <meta charset="utf-8">

  <title>BLueBlade DAC</title>

  <meta name="description" content="">

  <meta name="author" content="">


<!-- Mobile Specific Metas
  �������������������������������������������������� -->

  <meta name="viewport" content="width=device-width, initial-scale=1">


<!-- FONT
  (this font broken)�������������������������������������������������� -->

  <!-- <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

 -->
<!-- CSS
  �������������������������������������������������� -->

  <link rel="stylesheet" href="../../css/normalize.css">

  <link rel="stylesheet" href="../../css/skeleton.css">


<!-- Favicon
  �������������������������������������������������� -->

  <link rel="icon" type="image/png" href="../../images/favicon.png">

</head>
<body>


<!-- Primary Page Layout
  �������������������������������������������������� -->

<!-- Header
  �������������������������������������������������� -->

  <div class="container">

   <section class="header">
      <h2 class="title">BlueBlade DAC dashboard</h2>
      <div class="rowblue">
        <img class="value-img" src="../../images/BannerF.svg">
      </div>
    </section>
   </div>
<!-- navigation buttons
  �������������������������������������������������� -->

      <div class="container">
	<nav class="navbar">
        <div class="row">
    	  <div class="two columns">
	    <a class="button button-main" href="../../index.php" >   status   </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="../../errors.php">Info/errors</a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="../../charts.php">   charts   </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="../../settings.php"> settings </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="../../control.php">  Control  </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="../devices.php">  devices  </a>
	  </div>
        </div>
        </nav>
      </div>



<!-- Page content
  �������������������������������������������������� -->
<!-- php FUNCTIONS
-->
<?php
	$txt = "";
    	if ($_SERVER['REQUEST_METHOD'] == "POST"){
    		$val1 = $_REQUEST['val1'];
    		$val2 = $_REQUEST['val2'];
    		$val3 = $_REQUEST['val3'];
    		$val4 = $_REQUEST['val4'];
    		$postNameArr = array('light_toggle', 'Heater_off','TBD', 'LtimeOFF', 'LtimeON', 'tempdelta', 'tempgoal'); 
    		$postIdentifierArr = array();      
    		foreach ($postNameArr as $postName) {
    			if (array_key_exists($postName, $_POST)) {
    				$postIdentifierArr[] = $postName;
    			}
    		}
    		switch ($postIdentifierArr[0]){
    		case 'light_toggle':	
    			$txt = ("light_toggle\r\n" );
    			writetoard($txt);
    		break;
    		case 'Heater_off':
    			//$txt = ("A1 Heater_off " . $val1 . " " . $val2 . " /n" );
    			$txt = ("Heater_toggle\r\n" );
    			writetoard($txt);
    		break;
    		case 'TBD':	
    			$txt = ("TBD\r\n" );
    			writetoard($txt);
    		break;
    		case 'LtimeOFF':
    			writetoDB($postIdentifierArr[0], $val1, $val2, $val3, $val4 );
    		break;
    		case 'LtimeON':
    			writetoDB($postIdentifierArr[0], $val1, $val2, $val3, $val4 );
    		break;
    		case 'tempdelta':
    			writetoDB($postIdentifierArr[0], $val1, $val2, $val3, $val4 );
    		break;
    		case 'tempgoal':
    			writetoDB($postIdentifierArr[0], $val1, $val2, $val3, $val4 );
    		break;
    		}
    	}
function phpAlert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}
function writetoard($outtxt) {
    $fh = fopen('/app/tank/www/devices/ESPcont1/data.txt','w'); //<-- update path here -->
    fwrite($fh, $outtxt);
    fclose($fh);
    sleep(3);
    phpAlert("command sent " . $outtxt);
}
function writetoDB($variable, $v1, $v2, $v3, $v4) {
	include '../../SQLconn.php';
	// Create connection
	$conn = new mysqli($servername, $username, $password, $devicedbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = ("UPDATE ESPcont1_conf SET val1=" . $v1 . ", val2=" . $v2 . ", val3=". $v3 . ", val4=". $v4 . " WHERE varname='" . $variable . "'"); //<-- update setting DB here -->
	if ($conn->query($sql) === TRUE) {
		phpAlert("Record updated successfully");
	} else {
		phpAlert("Error updating record: " . mysqli_error($conn));
	}
	mysqli_close($conn);
	$conn->close();
}
?> 
<!-- END php FUNCTIONS -->
  
  <div class="container">
    <div class="row">
      <div class="two columns" style="margin-top: 2%">

      <h5>Device:</h5>
        <?php include '/app/tank/www/devices/toolbar.html'; ?> 
      </div>

      <div class="ten columns" style="margin-top: 2%">
        <h5>Terrarium - ESP8266 controller 1</h5>
</div> 
 <!-- time report -->
<div class="four columns">
        device time: 
        <?php
        $fh = fopen('/app/tank/www/devices/ESPcont1/time.txt','r');
        while ($line = fgets($fh)) {
        	echo($line);
        }
        fclose($fh);     
        ?> 
</div>       
<!-- function buttons -->
	  <div class="two columns">
		<form action="index.php" method="post">
        <input type="hidden" name="val1" value="0">
        <input type="hidden" name="val2" value="0">
 	    <input type="hidden" name="val3" value="0">
 	    <input type="hidden" name="val4" value="0">
        <input class="button-primary" type="submit" name="light_toggle" value=" Toggle Lights " />
        </form>   
      </div> 
	  <div class="two columns">
        <form action="index.php" method="post">
        <input type="hidden" name="val1" value="0">
        <input type="hidden" name="val2" value="0">
 	    <input type="hidden" name="val3" value="0">
 	    <input type="hidden" name="val4" value="0">
        <input class="button-primary" type="submit" name="Heater_off" value=" Disable heater" />
        </form>
      </div> 
	  <div class="two columns">
		<form action="index.php" method="post">
        <input type="hidden" name="val1" value="0">
        <input type="hidden" name="val2" value="0">
 	    <input type="hidden" name="val3" value="0">
 	    <input type="hidden" name="val4" value="0">
        <input class="button-primary" type="submit" name="TBD" value="  misc TBD  " />
        </form>   
      </div> 
<!-- current status table 1 -->
     <div class="ten columns">
        <h5>System Status</h5>
	<table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>Name</th>
      			<th>Value</th>
      			<th>Time</th>
    		</tr>
  	   </thead>
  	   <tbody>
<?php include '../../SQLconn.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $devicedbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val, stamp FROM recent WHERE log_table='esp1_log'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["varname"]. "</td><td>" . $row["val"]. "</td><td>" . $row["stamp"]. "</td></tr>";
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();
?>
  	   </tbody>
	</table>
	</div>
<!-- end current status table 1 -->
     <div class="twelve columns">     
<!-- display settings table 2 -->
     <div class="six columns">
        <h5>System Settings</h5>
	<table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>Name</th>
      			<th>Value1</th>
      			<th>Value2</th>
      			<th>Value3</th>
      			<th>Value4</th>
    		</tr>
  	   </thead>
  	   <tbody>
<?php include 'SQLconn.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $devicedbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val1, val2 ,val3, val4, stamp FROM ESPcont1_conf";  //<-- update setting DB here -->
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["varname"]. "</td><td>" . $row["val1"]. "</td><td>" . $row["val2"]. "</td><td>" . $row["val3"]. "</td><td>" . $row["val4"]. "</td></tr>";
        $thistime = strtotime($row["stamp"]);
        if ($thistime > $updatetime){
        	$updatetime=$thistime;
        }
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();
?>
  	   </tbody>
	</table>
	</div>
<!-- display settings table 3 -->
     <div class="six columns">
<!-- settings table
-->

	<table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>Change Settings</th><th>            </th>
      		</tr>
      	</thead>
  	   <tbody>
<form action="index.php" method="post">
	<tr><td>
     LtimeOFF
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
      Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20" selected>20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeOFF" value="Submit"/>
</td></tr></form>
	<form action="index.php" method="post">
		<tr><td>
  		    LtimeON
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9" selected>09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeON" value="Submit"/>
 	  </td></tr>
 	</form>

 		<form action="index.php" method="post">
		<tr><td>
  		    tempdelta
            <select name="val1">
 	       	<option value="1" selected>1 deg</option>
 	       	<option value="2">2 deg</option>
            <option value="3">3 deg</option>
 	       	<option value="4">4 deg</option>
 	        <option value="5">5 deg</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempdelta" value="Submit"/>
 	  </td></tr>
 	</form>
 	<form action="index.php" method="post">
		<tr><td>
  		 tempgoal
            <select name="val1">
 	       	<option value="65">65 deg F</option>
 	       	<option value="66">66 deg F</option>
            <option value="67">67 deg F</option>
 	       	<option value="68">68 deg F</option>
 	        <option value="69">69 deg F</option>
 	        <option value="70">70 deg F</option>
            <option value="71">71 deg F</option>
 	       	<option value="72">72 deg F</option>
 	        <option value="73">73 deg F</option>
 	        <option value="74">74 deg F</option>
            <option value="75">75 deg F</option>
 	       	<option value="76" selected>76 deg F</option>
 	        <option value="77">77 deg F</option>
 	        <option value="78">78 deg F</option>
 	        <option value="79">79 deg F</option>
            <option value="80">80 deg F</option>
 	       	<option value="81">81 deg F</option>
 	        <option value="82">82 deg F</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempgoal" value="Submit"/>
 	  </td></tr>
 	</form>
   </tbody>
</table>           
             
    </div>

<!-- End Document
  �������������������������������������������������� -->
  </div>
</body>

</html>
