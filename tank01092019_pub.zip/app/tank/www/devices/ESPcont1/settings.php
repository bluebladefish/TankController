<?php include '../../SQLconn.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $devicedbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val1, val2 ,val3, val4, stamp FROM ESPcont1_conf";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["varname"]. ":" . $row["val1"]. ":" . $row["val2"]. ":" . $row["val3"]. ":" . $row["val4"];
        echo "\r\n";
        $thistime = strtotime($row["stamp"]);
        if ($thistime > $updatetime){
        	$updatetime=$thistime;
        }
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();
?>