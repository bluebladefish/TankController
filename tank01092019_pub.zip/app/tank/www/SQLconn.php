<?php
$servername = "localhost";
$username = "sqladmin";
$password = "password";
$dbname = "tank";
$devicedbname = "devices";
?>
