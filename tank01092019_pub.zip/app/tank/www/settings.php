<!DOCTYPE html>

<html lang="en">

<head>

  
<!-- Basic Page Needs
  �������������������������������������������������� -->

  <meta charset="utf-8">

  <title>BLueBlade DAC</title>

  <meta name="description" content="">

  <meta name="author" content="">


<!-- Mobile Specific Metas
  �������������������������������������������������� -->

  <meta name="viewport" content="width=device-width, initial-scale=1">


<!-- FONT
  (this font broken)�������������������������������������������������� -->

  <!-- <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

 -->
<!-- CSS
  �������������������������������������������������� -->

  <link rel="stylesheet" href="css/normalize.css">

  <link rel="stylesheet" href="css/skeleton.css">


<!-- Favicon
  �������������������������������������������������� -->

  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>


<!-- Primary Page Layout
  �������������������������������������������������� -->

<!-- Header
  �������������������������������������������������� -->

  <div class="container">

   <section class="header">
      <h2 class="title">BlueBlade DAC dashboard</h2>
      <div class="rowblue">
        <img class="value-img" src="images/BannerF.svg">
      </div>
    </section>
   </div>
<!-- navigation buttons
  �������������������������������������������������� -->

      <div class="container">
	<nav class="navbar">
        <div class="row">
    	  <div class="two columns">
	    <a class="button button-main" href="index.php" >   status   </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="errors.php">Info/errors</a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="charts.php">   charts   </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="settings.php"> settings </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="control.php">  Control  </a>
	  </div>
	  <div class="two columns">
	    <a class="button button-main" href="devices/devices.php">  devices  </a>
	  </div>
        </div>
        </nav>
      </div>



<!-- Page content
  �������������������������������������������������� -->
<!-- php FUNCTIONS
-->
<?php
	$txt = "no text sent";
	$curtime = date("m-d-Y H:i:s");
	$updatetime = "0";
	$buttontext="  Request Current Config  ";
	$button2text="    Update Arduino Clock    ";
    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['getsetup'])){
        phpAlert( "config data reloaded" );
        $buttontext=" Current Config loaded ";
        $txt = "A2 setup\n";
    	writetoard($txt);
    } elseif($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['settime'])){
        phpAlert( "Arduino Clock updated" );
        $button2text=" Arduino Clock updated ";
        $txt = ("A3 u " . date("Y m d H i s") . " \n");
    	writetoard($txt);
    } else {
    	if ($_SERVER['REQUEST_METHOD'] == "POST"){
    		$val1 = $_REQUEST['val1'];
    		$val2 = $_REQUEST['val2'];
    		$val3 = $_REQUEST['val3'];
    		$val4 = $_REQUEST['val4'];
    		$postNameArr = array('blueLtTimeOFFreef', 'blueLtTimeONreef', 'Ltfadeduration', 'LtimeOFFplant', 'LtimeOFFsump',
    			'LtimeONplant', 'LtimeONsump', 'Maxtopofftime', 'MoonPhase', 'tempdeltaplant', 'tempdeltareef',
    			'tempgoalplant', 'tempgoalreef', 'WaveDuration', 'whiteLtTimeOFFreef', 'whiteLtTimeONreef'); 
    		$postIdentifierArr = array();      
    		foreach ($postNameArr as $postName) {
    			if (array_key_exists($postName, $_POST)) {
    				$postIdentifierArr[] = $postName;
    			}
    		}
    		switch ($postIdentifierArr[0]){
    		case 'blueLtTimeOFFreef':
    			$txt = ("A1 blueLtTimeOFFreef " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'blueLtTimeONreef':
    			$txt = ("A1 blueLtTimeONreef " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'Ltfadeduration':
    			$txt = ("A1 Ltfadeduration " . $val1 . " /n" );
    		break;
    		case 'LtimeOFFplant':
    			$txt = ("A1 LtimeOFFplant " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'LtimeOFFsump':
    			$txt = ("A1 LtimeOFFsump " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'LtimeONplant':
    			$txt = ("A1 LtimeONplant " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'LtimeONsump':
    			$txt = ("A1 LtimeONsump " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'Maxtopofftime':
    			$txt = ("A1 Maxtopofftime " . $val1 . " /n" );
    		break;
    		case 'MoonPhase':
    			$txt = ("A1 MoonPhase " . $val1 . " /n" );
    		break;
    		case 'tempdeltaplant':
    			$txt = ("A1 tempdeltaplant " . $val1 . " /n" );
    		break;
    		case 'tempdeltareef':
    			$txt = ("A1 tempdeltareef " . $val1 . " /n" );
    		break;
    		case 'tempgoalplant':
    			$txt = ("A1 tempgoalplant " . $val1 . " /n" );
    		break;
    		case 'tempgoalreef':
    			$txt = ("A1 tempgoalreef " . $val1 . " /n" );
    		break;
    		case 'WaveDuration':
    			$txt = ("A1 WaveDuration " . $val1 . " " . $val2 . " " . $val3 . " " . $val4 . " /n" );
    		break;
    		case 'whiteLtTimeOFFreef':
    			$txt = ("A1 whiteLtTimeOFFreef " . $val1 . " " . $val2 . " /n" );
    		break;
    		case 'whiteLtTimeONreef':
    			$txt = ("A1 whiteLtTimeONreef " . $val1 . " " . $val2 . " /n" );
    		break;
    		}
    		writetoDB($postIdentifierArr[0], $val1, $val2, $val3, $val4 );
    		//phpAlert($txt);
    		writetoard($txt);
    	}
    }
function phpAlert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}
function writetoard($outtxt) {
    $fh = fopen('/app/tank/serial_out.txt','w');
    fwrite($fh, $outtxt);
    fclose($fh);
    sleep(3);
}
function writetoDB($variable, $v1, $v2, $v3, $v4) {
	include 'SQLconn.php';
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = ("UPDATE saved_conf SET val1=" . $v1 . ", val2=" . $v2 . ", val3=". $v3 . ", val4=". $v4 . " WHERE varname='" . $variable . "'");
	if ($conn->query($sql) === TRUE) {
		phpAlert("Record updated successfully");
	} else {
		phpAlert("Error updating record: " . mysqli_error($conn));
	}
	mysqli_close($conn);
	$conn->close();
}
?> 
<!-- END php FUNCTIONS
-->
  <div class="container">
    <div class="row">
      <div class="one-half column" style="margin-top: 2%">
      <form action="/tank/settings.php" method="post">
      <table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>
      				Server time: <br> <?php echo($curtime);?>
      			</th>
      			<th>
      				<input class="button-primary" type="submit" name="getsetup" value="<?php echo($buttontext); ?>" />
      			
     			</th>
    		</tr>
  	   </thead>
	</table>
	</form>

<!-- table 1 -->
        <h5>Arduino Variables</h5>
	<table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>Name</th>
      			<th>Value1</th>
      			<th>Value2</th>
      			<th>Value3</th>
      			<th>Value4</th>
    		</tr>
  	   </thead>
  	   <tbody>
<?php include 'SQLconn.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT varname, val1, val2 ,val3, val4, stamp FROM current_conf";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["varname"]. "</td><td>" . $row["val1"]. "</td><td>" . $row["val2"]. "</td><td>" . $row["val3"]. "</td><td>" . $row["val4"]. "</td></tr>";
        $thistime = strtotime($row["stamp"]);
        if ($thistime > $updatetime){
        	$updatetime=$thistime;
        }
    }
} else {
    echo "Database error (0 results found)";
}
$conn->close();
?>
  	   </tbody>
	</table>
	<h4> last update: <?php echo(date("Y-m-d H:i:s", $updatetime));?> </h4>	
<!-- end table 1 -->

      </div>
      
<!-- columb 2 -->
      <div class="one-half column" style="margin-top: 2%">
      <form action="/tank/settings.php" method="post">
      <table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>
      				Arduino time: <br> 
<?php
$fh2 = fopen('/app/tank/P3_in.txt','r');
while ($line2 = fgets($fh2)) {
	echo($line2);
	echo '<br>'; 
}
fclose($fh2);     
?> 
				</th><th>
      			  	<input class="button-primary" type="submit" name="settime" value="<?php echo($button2text); ?>" />
      			</th>
    		</tr>
  	   </thead>
	</table>
	</form>
	
<!-- settings table
-->

	<table class="u-full-width">
  	   <thead>
    		<tr>
      			<th>Change Settings</th><th>            </th>
      		</tr>
      	</thead>
  	   <tbody>
<form action="/tank/settings.php" method="post">
	<tr><td>
      blueLtTimeOFFreef
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
      Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20" selected>20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="blueLtTimeOFFreef" value="Submit"/>
</td></tr></form>
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    blueLtTimeONreef
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9" selected>09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="blueLtTimeONreef" value="Submit"/>
 	  </td></tr>
 	</form>
 	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    Ltfadeduration
            <select name="val1">
 	       	<option value="15">15</option>
 	       	<option value="30">30</option>
 	        <option value="45">45</option>
 	        <option value="60">60</option>
 	        <option value="75">75</option>
 	       	<option value="90" selected>90</option>
 	        <option value="105">105</option>
 	        <option value="120">120</option>
 	        <option value="135">135</option>
 	        <option value="150">150</option>
 	        <option value="165">165</option>
 	       	<option value="180">180</option>
 	       	</select>
 	       	Min 
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="Ltfadeduration" value="Submit"/>
 	  </td></tr>
 	</form>
 	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    LtimeOFFplant
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22" selected>22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeOFFplant" value="Submit"/>
 	  </td></tr>
 	</form>
	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    LtimeOFFsump
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11" selected>11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeOFFsump" value="Submit"/>
 	  </td></tr>
 	</form>
 	
	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    LtimeONplant
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9" selected>09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeONplant" value="Submit"/>
 	  </td></tr>
 	</form>
 	
	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    LtimeONsump
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19" selected>19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="LtimeONsump" value="Submit"/>
 	  </td></tr>
 	</form>
 	
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    Maxtopofftime
            <select name="val1">
 	       	<option value="15">15</option>
 	       	<option value="30">30</option>
            <option value="45">45</option>
 	       	<option value="60">60</option>
 	        <option value="90">90</option>
 	        <option value="120" selected>120</option>
 	        <option value="150">150</option>
 	       	<option value="180">180</option>
 	        <option value="210">210</option>
 	        <option value="240">240</option>
 	        <option value="270">270</option>
 	       	<option value="300">300</option>
 	        <option value="360">360</option>
 	        <option value="420">420</option>
 	       	<option value="480">480</option>
 	       	<option value="500">500</option>
 	       	</select>
 	       	Seconds 
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="Maxtopofftime" value="Submit"/>
 	  </td></tr>
 	</form>

	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    MoonPhase
            <select name="val1">
 	       	<option value="0">0-new</option>
 	       	<option value="1">1-new</option>
            <option value="2">2-first-crescent</option>
 	       	<option value="3">3-first-crescent</option>
 	        <option value="4">4-first-quarter</option>
 	        <option value="5" selected>5-first-quarter</option>
 	        <option value="6">6-first-3/7</option>
 	       	<option value="7">7-first-3/7</option>
 	        <option value="8">8-first-half</option>
 	        <option value="9">9-first-half</option>
 	        <option value="10">10-first-5/7</option>
 	       	<option value="11">11-first-5/7</option>
 	        <option value="12">12-first-6/7</option>
 	        <option value="13">13-first-6/7</option>
 	       	<option value="14">14-full</option>
 	       	<option value="15">15-full</option>
 	       	<option value="16">16-last-6/7</option>
 	       	<option value="17">17-last-6/7</option>
 	        <option value="18">18-last-5/7</option>
 	        <option value="19">19-last-5/7</option>
 	       	<option value="20">20-last-half</option>
 	       	<option value="21">21-last-half</option>
            <option value="22">22-last-3/7</option>
 	       	<option value="23">23-last-3/7</option>
 	        <option value="24">2425-last-quarter</option>
 	        <option value="25">25-last-quarter</option>
 	        <option value="26">26-last-crescent</option>
 	       	<option value="27">27-last-crescent</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="MoonPhase" value="Submit"/>
 	  </td></tr>
 	</form>
 	
 		<form action="/tank/settings.php" method="post">
		<tr><td>
  		    tempdeltaplant
            <select name="val1">
 	       	<option value="1" selected>1 deg</option>
 	       	<option value="2">2 deg</option>
            <option value="3">3 deg</option>
 	       	<option value="4">4 deg</option>
 	        <option value="5">5 deg</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempdeltaplant" value="Submit"/>
 	  </td></tr>
 	</form>
 	
 	
 		<form action="/tank/settings.php" method="post">
		<tr><td>
  		    tempdeltareef
            <select name="val1">
 	       	<option value="1" selected>1 deg</option>
 	       	<option value="2">2 deg</option>
            <option value="3">3 deg</option>
 	       	<option value="4">4 deg</option>
 	        <option value="5">5 deg</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempdeltareef" value="Submit"/>
 	  </td></tr>
 	</form>
 	
 		<form action="/tank/settings.php" method="post">
		<tr><td>
  		    tempgoalplant
            <select name="val1">
 	       	<option value="65">65 deg F</option>
 	       	<option value="66">66 deg F</option>
            <option value="67">67 deg F</option>
 	       	<option value="68">68 deg F</option>
 	        <option value="69">69 deg F</option>
 	        <option value="70">70 deg F</option>
            <option value="71">71 deg F</option>
 	       	<option value="72">72 deg F</option>
 	        <option value="73">73 deg F</option>
 	        <option value="74">74 deg F</option>
            <option value="75">75 deg F</option>
 	       	<option value="76" selected>76 deg F</option>
 	        <option value="77">77 deg F</option>
 	        <option value="78">78 deg F</option>
 	        <option value="79">79 deg F</option>
            <option value="80">80 deg F</option>
 	       	<option value="81">81 deg F</option>
 	        <option value="82">82 deg F</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempgoalplant" value="Submit"/>
 	  </td></tr>
 	</form>
 		
 	
 		<form action="/tank/settings.php" method="post">
		<tr><td>
  		    tempgoalreef
            <select name="val1">
 	       	<option value="65">65 deg F</option>
 	       	<option value="66">66 deg F</option>
            <option value="67">67 deg F</option>
 	       	<option value="68">68 deg F</option>
 	        <option value="69">69 deg F</option>
 	        <option value="70">70 deg F</option>
            <option value="71">71 deg F</option>
 	       	<option value="72">72 deg F</option>
 	        <option value="73">73 deg F</option>
 	        <option value="74">74 deg F</option>
            <option value="75">75 deg F</option>
 	       	<option value="76" selected>76 deg F</option>
 	        <option value="77">77 deg F</option>
 	        <option value="78">78 deg F</option>
 	        <option value="79">79 deg F</option>
            <option value="80">80 deg F</option>
 	       	<option value="81">81 deg F</option>
 	        <option value="82">82 deg F</option>
 	       	</select>
 	       	<input type="hidden" name="val2" value="0">
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="tempgoalreef" value="Submit"/>
 	  </td></tr>
 	</form>

	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    WaveDuration
            <select name="val1">
 	       	<option value="30">30 SecOn</option>
 	        <option value="45">45 SecOn</option>
 	        <option value="60" selected>60 SecOn</option>
 	        <option value="75">75 SecOn</option>
 	       	<option value="90">90 SecOn</option>
 	        <option value="120">2 MinOn</option>
 	       	<option value="180">3 MinOn</option>
  	        <option value="240">4 MinOn</option>
 	       	<option value="300">5 MinOn</option>
 	       	<option value="360">6 MinOn</option>
 	       	<option value="420">7 MinOn</option>
 	       	<option value="480">8 MinOn</option>
 	       	<option value="540">9 MinOn</option>
 	       	<option value="600">10 MinOn</option>
 	       	</select>
 	       	Bank 1 time on
            <select name="val2">
 	       	<option value="30">30 SecOff</option>
 	        <option value="45">45 SecOff</option>
 	        <option value="60" selected>60 SecOff</option>
 	        <option value="75">75 SecOff</option>
 	       	<option value="90">90 SecOff</option>
 	        <option value="120">2 MinOff</option>
 	       	<option value="180">3 MinOff</option>
  	        <option value="240">4 MinOff</option>
 	       	<option value="300">5 MinOff</option>
 	       	<option value="360">6 MinOff</option>
 	       	<option value="420">7 MinOff</option>
 	       	<option value="480">8 MinOff</option>
 	       	<option value="540">9 MinOff</option>
 	       	<option value="600">10 MinOff</option>
 	       	</select>
 	       	Bank 1 time off
 	       	<select name="val3">
 	       	<option value="30">30 SecOn</option>
 	        <option value="45">45 SecOn</option>
 	        <option value="60" selected>60 SecOn</option>
 	        <option value="75">75 SecOn</option>
 	       	<option value="90">90 SecOn</option>
 	        <option value="120">2 MinOn</option>
 	       	<option value="180">3 MinOn</option>
  	        <option value="240">4 MinOn</option>
 	       	<option value="300">5 MinOn</option>
 	       	<option value="360">6 MinOn</option>
 	       	<option value="420">7 MinOn</option>
 	       	<option value="480">8 MinOn</option>
 	       	<option value="540">9 MinOn</option>
 	       	<option value="600">10 MinOn</option>
 	       	</select>
 	       	Bank 2 time on
            <select name="val4">
 	       	<option value="30">30 SecOff</option>
 	        <option value="45">45 SecOff</option>
 	        <option value="60" selected>60 SecOff</option>
 	        <option value="75">75 SecOff</option>
 	       	<option value="90">90 SecOff</option>
 	        <option value="120">2 MinOff</option>
 	       	<option value="180">3 MinOff</option>
  	        <option value="240">4 MinOff</option>
 	       	<option value="300">5 MinOff</option>
 	       	<option value="360">6 MinOff</option>
 	       	<option value="420">7 MinOff</option>
 	       	<option value="480">8 MinOff</option>
 	       	<option value="540">9 MinOff</option>
 	       	<option value="600">10 MinOff</option>
 	       	</select>
 	       	Bank 2 time off
 	        </td><td>
 	        <input class="button-primary" type="submit" name="WaveDuration" value="Submit"/>
 	  </td></tr>
 	</form>
 	
<form action="/tank/settings.php" method="post">
	<tr><td>
      whiteLtTimeOFFreef
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
      Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9">09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20" selected>20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="whiteLtTimeOFFreef" value="Submit"/>
</td></tr></form>
	<form action="/tank/settings.php" method="post">
		<tr><td>
  		    whiteLtTimeONreef
            <select name="val1">
 	       	<option value="1">1</option>
 	       	<option value="5">5</option>
 	        <option value="10">10</option>
 	        <option value="15" selected>15</option>
 	        <option value="20">20</option>
 	       	<option value="25">25</option>
 	        <option value="30">30</option>
 	        <option value="35">35</option>
 	        <option value="40">40</option>
 	        <option value="45">45</option>
 	        <option value="50">50</option>
 	       	<option value="55">55</option>
 	       	</select>
 	       	Min 
            <select name="val2">
 	       	<option value="0">00</option>
 	       	<option value="1">01</option>
 	       	<option value="2">02</option>
 	        <option value="3">03</option>
 	        <option value="4">04</option>
 	        <option value="5">05</option>
 	       	<option value="6">06</option>
 	        <option value="7">07</option>
 	        <option value="8">08</option>
 	        <option value="9" selected>09</option>
 	        <option value="10">10</option>
 	        <option value="11">11</option>
 	       	<option value="12">12</option>
 	       	<option value="13">13</option>
 	       	<option value="14">14</option>
 	        <option value="15">15</option>
 	        <option value="16">16</option>
 	        <option value="17">17</option>
 	       	<option value="18">18</option>
 	        <option value="19">19</option>
 	        <option value="20">20</option>
 	        <option value="21">21</option>
 	        <option value="22">22</option>
 	        <option value="23">23</option>
 	        </select>
 	        Hr 
 	        <input type="hidden" name="val3" value="0">
 	        <input type="hidden" name="val4" value="0">
 	        </td><td>
 	        <input class="button-primary" type="submit" name="whiteLtTimeONreef" value="Submit"/>
 	  </td></tr>
 	</form>
 	
  </tbody>
</table>

      </div>

    </div>

  </div>


<!-- End Document
  �������������������������������������������������� -->

</body>

</html>
