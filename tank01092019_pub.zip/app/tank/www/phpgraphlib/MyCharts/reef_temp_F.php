<?php

include('../phpgraphlib.php');
include('../../SQLconn.php');

//$days = unserialize(urldecode(stripslashes($_GET['myduration'])));
$days = ($_GET['myduration']);
//$days = 2;
$set1 = array();
$set2 = array();
$day7 = strtotime("-" . $days . " days");
//$small = "2018-07-24 00:10:00";
$small = date("Y-m-d", $day7) . " 00:10:00";
$large = date("Y-m-d H:i:s");
//$large = "2018-08-01 00:10:00";
$skip = $days * 3;
$skipcount = 0;

//SQL
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//get data set1 from database
$sql = "SELECT * FROM env_log WHERE varname='Reef_temp' AND stamp BETWEEN '".$small."' AND '".$large."' ORDER BY stamp" ;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $itemValue=$row["val"];
      $itemstamp=$row["stamp"];
      $skipcount= $skipcount+1;
      //add to data array
      if ($skipcount >= $skip) {
      	  $set1[$itemstamp]=$itemValue;
      	  $skipcount = 0;
      }
  }
}
$conn->close();

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//get data set2 from database
$sql = "SELECT * FROM cont_log WHERE varname='reef_heater' AND stamp BETWEEN '".$small."' AND '".$large."' ORDER BY stamp";
//$sql = "SELECT * FROM to_log WHERE varname='Plant_TO_total' AND stamp BETWEEN '".$small."' AND '".$large."' ORDER BY stamp";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $itemValue=$row["val"];
      $itemstamp=$row["stamp"];
      //add to data array
      if ($itemValue == "ON"){
	$itemValue_convert=82;
      } else {
	$itemValue_convert=68;
      }
      $set2[$itemstamp]=$itemValue_convert;
  }
}
$conn->close();

//configure graph
$graph = new PHPGraphLib(920, 800);
$graph->addData($set1, $set2);
$graph->setTitleLocation('left');
$graph->setTitle($days . " Day Reef temperature");
$graph->setBars(false);
$graph->setLine(true);
$graph->setDataPoints(false);
$graph->setLineColor('blue', 'red');
$graph->setDataValues(false);
$graph->setXValuesInterval(2);
$graph->setDataValueColor('blue', 'red');
$graph->setLegend(true);
$graph->setLegendTitle("Reef", "heater");
$graph->setRange(82,68);
$graph->setupXAxis(26);
$graph->createGraph();


?>