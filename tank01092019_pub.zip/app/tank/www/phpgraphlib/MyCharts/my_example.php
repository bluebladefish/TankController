<?php

include('../phpgraphlib.php');
include('../../SQLconn.php');
//SQL
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$dataArray=array();
  
//get data from database
$sql = "SELECT * FROM env_log WHERE varname='Reef_temp'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $itemValue=$row["val"];
      $itemstamp=$row["stamp"];
      //add to data array
      $dataArray[$itemstamp]=$itemValue;
  }
}
$conn->close();

//configure graph
$graph = new PHPGraphLib(460, 400);
$graph->addData($dataArray);
$graph->setTitle("Reef Temperature");
$graph->setGradient("lime", "green");
$graph->setBarOutlineColor("black");
$graph->setRange(82,68);
$graph->setupXAxis(26);
//create the graph
$graph->createGraph();


?>